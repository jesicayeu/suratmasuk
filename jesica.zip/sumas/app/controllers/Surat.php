<?php
class Surat extends Controller {
    public function __construct()
{
if($_SESSION['session_login'] != 'sudah_login') { 
Flasher::setMessage('Login','Tidak ditemukan.','danger'); 
header('location: '. base_url . '/login');
exit;
}
}

public function index()
{
$data['title'] = 'Data Surat';
$data['surat'] = $this->model('SuratModel')->getAllSurat();
$this->view('templates/header', $data);
$this->view('templates/sidebar', $data);
$this->view('surat/index', $data);
$this->view('templates/footer');
}
public function cari()
{
    $data['title'] = 'Data Surat';
    $data['surat'] = $this->model('SuratModel')->cariSurat();
    $data['key'] = $_POST['key'];
    $this->view('templates/header' ,  $data);
    $this->view('templates/sidebar', $data);
    $this->view('surat/index', $data);
    $this->view('templates/footer');
}
public function edit($id)
{
    $data['title'] = 'Detail Surat';
    $data['keterangan'] = $this->model('KeteranganModel')->getAllKeterangan();
    $data['surat'] = $this->model('SuratModel')->getSuratById($id);
    $this->view('templates/header', $data);
    $this->view('templates/sidebar', $data);
    $this->view('surat/edit', $data);
    $this->view('templates/footer');
}
public function tambah()
{
    $data['title'] = 'Tambah Surat';
    $data['keterangan'] = $this->model('KeteranganModel')->getAllKeterangan();
    $this->view('templates/header', $data);
    $this->view('templates/sidebar', $data);
    $this->view('surat/create', $data);
    $this->view('templates/footer');
}
public function simpanSurat()
{
    if( $this->model('SuratModel')->tambahSurat($_POST) > 0 ) {
        Flasher::setMessage('Berhasil', 'ditambahkan','success');
        header('location: '. base_url . '/surat');
        exit;
    }else {
        Flasher::setMessage('Gagal', 'ditambahkan','danger');
        header('location: '. base_url . '/surat');
        exit;
    }
}
public function updateSurat()
{
    if( $this->model('SuratModel')->updateDataSurat($_POST) > 0 ) {
        Flasher::setMessage('Berhasil', 'diupdate', 'success');
        header('location: '. base_url . '/surat');
        exit;
    }else{
        Flasher::setMessage('Gagal', 'diupdate', 'danger');
        header('location: '. base_url . '/surat');
        exit;
    }
}
public function hapus($id)
{
    if($this->model('SuratModel')->deleteSurat($id) > 0 ) {
        Flasher::setMessage('Berhasil', 'dihapus','success');
        header('location: '. base_url . '/surat');
        exit;
    }else{
        Flasher::setMessage('Gagal', 'dihapus','danger');
        header('location: '. base_url . '/surat');
        exit;
    }
}
public function lihatlaporan()
{
$data['title'] = 'Data Laporan Surat';
$data['surat'] = $this->model('SuratModel')->getAllSurat();
$this->view('surat/lihatlaporan', $data);
}
public function laporan()
{
$data['surat'] = $this->model('SuratModel')->getAllSurat();
$pdf = new FPDF('p','mm','A4');
// membuat halaman baru
$pdf->AddPage();
// setting jenis font yang akan digunakan
$pdf->SetFont('Arial','B',14);
// mencetak string
$pdf->Cell(190,7,'LAPORAN SURAT',0,1,'C');
// Memberikan space kebawah agar tidak terlalu rapat
$pdf->Cell(10,7,'',0,1);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(85,6,'TANGGAL',1);
$pdf->Cell(30,6,'NOMOR_SURAT',1);
$pdf->Cell(30,6,'DARI',1);
$pdf->Cell(25,6,'KETERANGAN',1);
$pdf->Cell(15,6,'PERIHAL',1);
$pdf->Ln();
$pdf->SetFont('Arial','',10);
foreach($data['surat'] as $row) {
$pdf->Cell(85,6,$row['tanggal'],1);
$pdf->Cell(30,6,$row['nomor_surat'],1);
$pdf->Cell(30,6,$row['dari'],1);
$pdf->Cell(25,6,$row['nama_keterangan'],1);
$pdf->Cell(15,6,$row['perihal'],1);
$pdf->Ln();
}
$pdf->Output('D', 'Laporan Surat.pdf', true);
}

}
?>