<?php
class KeteranganModel {
    private $table = 'keterangan';
    private $db;

    public function __construct() {
        $this->db = new Database;
    }
    public function getAllKeterangan() {
        $this->db->query('SELECT * FROM ' . $this->table);
        return $this->db->resultSet();
    }
    public function getKeteranganById($id) {
       $this->db->query('SELECT * FROM ' . $this->table . ' WHERE id=:id');
       $this->db->bind('id' ,$id);
       return $this->db->single();
    }
    public function tambahKeterangan($data) {
        $query = "INSERT INTO keterangan (nama_keterangan) VALUES(:nama_keterangan)";
        $this->db->query($query);
        $this->db->bind('nama_keterangan' ,$data['nama_keterangan']);
        $this->db->execute();

        return $this->db->rowCount();
    }
    public function updateDataKeterangan($data) {
        $query = "UPDATE keterangan SET nama_keterangan=:nama_keterangan WHERE id=:id";
        $this->db->query($query);
        $this->db->bind('id',$data['id']);
        $this->db->bind('nama_keterangan' ,$data['nama_keterangan']);
        $this->db->execute();

        return $this->db->rowCount();
    }
    public function deleteKeterangan($id) {
        $this->db->query('DELETE FROM ' . $this->table . ' WHERE id=:id');
        $this->db->bind('id' ,$id);
        $this->db->execute();

        return $this->db->rowCount();
    }
    public function cariKeterangan() {
        $key = $_POST['key'];
        $this->db->query("SELECT * FROM " . $this->table . " WHERE nama_keterangan LIKE :key");
        $this->db->bind('key', "%$key%");
        return $this->db->resultSet();
    }
}
?>