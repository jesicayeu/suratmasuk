<?php
class SuratModel {
    private $table = 'surat';
    private $db;

    public function __construct() {
        $this->db = new Database;
    }
    public function getAllSurat() {
        $this->db->query("SELECT surat.*, keterangan.nama_keterangan FROM " . $this->table . " JOIN keterangan ON keterangan.id = surat.keterangan_surat");
        return $this->db->resultSet();
    }
    public function getSuratById($id) {
       $this->db->query('SELECT * FROM ' . $this->table . ' WHERE id=:id');
       $this->db->bind('id' ,$id);
       return $this->db->single();
    }
    public function tambahSurat($data) {
        $query = "INSERT INTO surat (tanggal, nomor_surat, dari, keterangan_surat, perihal) VALUES(:tanggal, :nomor_surat, :dari, :keterangan_surat, :perihal)";
        $this->db->query($query);
        $this->db->bind('tanggal' ,$data['tanggal']);
        $this->db->bind('nomor_surat' ,$data['nomor_surat']);
        $this->db->bind('dari' ,$data['dari']);
        $this->db->bind('keterangan_surat' ,$data['keterangan_surat']);
        $this->db->bind('perihal' ,$data['perihal']);
        $this->db->execute();

        return $this->db->rowCount();
    }
    public function updateDataSurat($data) {
        $query = "UPDATE surat SET tanggal=:tanggal, nomor_surat=:nomor_surat, dari=:dari, keterangan_surat=:keterangan_surat, perihal=:perihal WHERE id=:id";
        $this->db->query($query);
        $this->db->bind('id',$data['id']);
        $this->db->bind('tanggal' ,$data['tanggal']);
        $this->db->bind('nomor_surat' ,$data['nomor_surat']);
        $this->db->bind('dari' ,$data['dari']);
        $this->db->bind('keterangan_surat' ,$data['keterangan_surat']);
        $this->db->bind('perihal' ,$data['perihal']);
        $this->db->execute();

        return $this->db->rowCount();
    }
    public function deleteSurat($id) {
        $this->db->query('DELETE FROM ' . $this->table . ' WHERE id=:id');
        $this->db->bind('id' ,$id);
        $this->db->execute();

        return $this->db->rowCount();
    }
    public function cariSurat() {
        $key = $_POST['key'];
        $this->db->query("SELECT * FROM " . $this->table . " WHERE tanggal LIKE :key");
        $this->db->bind('key', "%$key%");
        return $this->db->resultSet();
    }
}
?>