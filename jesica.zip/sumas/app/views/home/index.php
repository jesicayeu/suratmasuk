<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<section class="content-header">
<div class="container-fluid">
<div class="row mb-2">
<div class="col-sm-6">
<h1><?= $data['title']; ?></h1>
</div>
</div>
</div><!-- /.container-fluid -->
</section>
<!-- Main content -->
<section class="content">
<!-- Default box -->
<div class="card">
<div class="card-header">
<h3 class="card-title">Apa yang dimaksud dengan Surat Masuk?</h3>
</div>
<div class="card-body">
Surat Masuk adalah informasi yang diterima melalui surat yang disampaikan dari pihak internal maupun
pihak eksternal,baik dari individu,lembaga atau organisasi lainnya.
Menurut Wursanto Pengelolaan surat masuk adalah proses kegiatan mencatat semua jenis surat yang diterima instansi lain
maupun perorangan,baik yang diterima melalui pos(kantor pos) maupun yang diterima dari kurir (pengirim surat)
dengan mempergunakan buku pengiriman (ekspedisi).
</div>
<!-- /.card-body -->
<div class="card-footer"> 
Jesica Yeuyanan SuMas 2023
</div>
<!-- /.card-footer-->
</div>
<!-- /.card -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->
