<?php
define('base_url', 'http://localhost/sumas/public');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'surat_masuk');
?>